#/bin/bash
hostname=$(hostname)
echo "--- Hostname: $hostname"
date=$(date)
echo "--- Date $date"
osrelease=$(cat /etc/os-release |head -1)
osver=$(cat /etc/os-release |head -2|tail -1)
echo "--- OS_Release $osrelease $osver"
echo "--- Last updates"
rpm -qa --last | head
